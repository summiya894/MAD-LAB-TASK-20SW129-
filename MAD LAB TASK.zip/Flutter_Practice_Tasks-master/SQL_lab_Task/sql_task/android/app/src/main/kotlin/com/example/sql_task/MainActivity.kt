package com.example.sql_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
