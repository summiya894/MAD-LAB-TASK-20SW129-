class Notes {
  int? id;
  String rollno;
  String name;
  Notes({this.id, required this.rollno, required this.name});
}
